const GameRepresentationIds = {
  WINGO: {
    1: "01",
    3: "02",
    5: "03",
    10: "04",
  },
  G5D: {
    1: "05",
    3: "06",
    5: "07",
    10: "08",
  },
  K3: {
    1: "09",
    3: "10",
    5: "11",
    10: "12",
  },
  TRXWINGO: {
    1: "13",
    3: "14",
    5: "15",
    10: "16",
  },
};
export default GameRepresentationIds;
